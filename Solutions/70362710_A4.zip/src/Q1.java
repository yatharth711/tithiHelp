
 import java.util.Scanner;


public class Q1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a  letter: ");
		char c = input.next().charAt(0);
		
		switch(c) {
		case 'a','e','i','o','u' -> System.out.printf("%c is a vowel",c);
		
		case 'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z' -> {System.out.printf("%c is consonant",c);
		}
		default -> System.out.printf("%c is an invalid input",c);
		}
		}
		

		

	}


