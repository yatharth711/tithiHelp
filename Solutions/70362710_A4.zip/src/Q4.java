import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Scissors(0),rocks(1),paper(2): ");
		int number = input.nextInt();	
		int chance = (int)(Math.random() * 3);
		
		
		System.out.print("The computer is  ");
		switch (chance) {
		case 0 : System.out.print("scissors.");break;
		case 1 : System.out.print("rock.");break;
		case 2 : System.out.print("paper.");
		}
		
	    System.out.print("You are ");
	    switch (number) {
	    case 0 : System.out.print("scissors.");break;
	    case 1: System.out.print("rock.");break;
	    case 2 : System.out.print("paper.");
	    }
		
		if(number == chance ) {
			System.out.println("its a draw");
		}else { 
			boolean win = (number == 0 && chance == 2 || number == 1 && chance == 0 || number == 2 && chance == 1  );
				
			if(win)
				System.out.print(" You won" );
			else 
				System.out.print(" You lost");
			
		 
		
				
		
		}
		
		
		}
		

	}


