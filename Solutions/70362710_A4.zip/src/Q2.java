
 import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print(" Enter a valid plate number : ");
		String numberplate = input.nextLine();
		
		int length = numberplate.length();
		
				
		char letter1 = numberplate.charAt(0);
		char letter2 = numberplate.charAt(1);
		char letter3 = numberplate.charAt(2);
		char letter4 = numberplate.charAt(3);
		char letter5 = numberplate.charAt(4);
		if(Character.isUpperCase(letter1) & length == 5 
				& Character.isUpperCase(letter2) & letter3 == '-' & Character.isDigit(letter4)& Character.isDigit(letter5)  ) {
			System.out.printf("%s is a valid number plate",numberplate);			
		}else{
			System.out.printf("%s is an invalid number plate",numberplate);
		}
		
		}
		
	}
