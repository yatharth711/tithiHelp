
public class Q2 {

	public static void main(String[] args) {
		System.out.println("list of perfect numbers- ");

		int numbers;	
		
		for (int i = 1; i < 10000; i++) {
			numbers = 0;	

			for (int j = 1; j < i; j++) {
				
				if (i % j == 0)
					numbers += j;
			}
			
			if (i == numbers)
				System.out.printf("%20d\n", i);

		for (int n = 1; n <= 10000; n++) {
			boolean setPerfectNumber = i == numbers;

	}

}
	}
}
