
import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int sum = 0,count = 0,p = 0,n =0,e=0,o=0;
		double average = 0;
		
		System.out.print("Enter the first interger (0 to terminate): ");
		int x = input.nextInt();	
		
		if (x == 0) {
			System.out.println("no number entered except 0 ");
		}else {
			
		while ( x != 0) {                //sum of the numbers 
			sum += x;
			if(x > 0)
				p++;
			if(x <0)
				n++;
			if (x % 2 == 0)
				e++;
			if(x % 2 == 1)
				o++;
			count++;
			System.out.print("Enter the next integer (0 to terminate): ");
			x = input.nextInt();
			
		
		}
		if (true)
		{
			average = (double)sum/count;
		}
		
		
		
		
		
		System.out.println("The number of positives is " + p);
		System.out.println("The number of negatives "+ n);
		System.out.println("The number evens is "+ e);
		System.out.println("The number odds is "+ o);
		System.out.println("The total is "+ sum);
		System.out.printf("The average is %.2f",average);
		}			
	}
}