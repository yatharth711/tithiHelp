
import java.util.Scanner;
public class Q4 {

	public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
		    System.out.print("Enter the number of students: ");
		    int num = input.nextInt();
		    System.out.print("Enter the student's name: ");
		    String name1 = input.next();
		    System.out.print("Enter the student's score: ");
		    double s1 = input.nextDouble();		    
		    System.out.print("Enter the student's name: ");
		    String name2 = input.next();
		    System.out.print("Enter the student's score: ");
		    double s2 = input.nextDouble();
		    

		    for (int i = 1; i < num - 1; i++) 
		    {
		        System.out.print("Enter the student's name: ");
		        String name = input.next();
		        System.out.print("Enter the student's score: ");
		        double s = input.nextDouble();
                
		        if (s > s1) {
		        	name1=name;
		        	s1=s;
		        }
		        else if(s > s2 ) {
		        	name2=name;
		        	s2=s;
		        }
		    }
		    System.out.println("Top two students: ");
		    System.out.printf("%s's score is %.1f \n", name1,s1);
		    System.out.printf("%s's score is %.1f \n", name2,s2);

}
	}

