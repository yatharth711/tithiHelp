import java.util.Scanner;
public class Q3 {
		
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		String[][] capitals = inputData();
		int count = 0;					
		
		for (int i = 0; i < capitals.length; i++) {
			System.out.print("What is the capital of "
				+ capitals[i][0] + "? ");
			String capital = input.nextLine();			
				
			}
		System.out.println("\nThe correct count is " + count);
		
	}
	public static boolean caseSens(String a, String b){
		if(a.length() != b.length())
			return false;
		
		for (int i = 0; i < a.length(); i++) {
			if (a.charAt(i) != b.charAt(i))
				return false;
		}
		return true;
	}
	public static String[][] inputData(){
		String[][] s = 	{{"Alberta","Edmonton"},
				{"British Columbia","Victoria"},
				{"Manitoba","Winnipeg"},
				{"New Brunswick","Fredericton"},
				{"Newfoundland and Labrador","St. John's"},
				{"Nova Scotia","Halifax"},
				{"Ontario","Toronto"},
				{"Prince Edward Island","Charlottetown"},
				{"Quebec","Quebec City"},
				{"Saskatchewan","Regina"},};
		return s;
	}
}
		
