
public class Q1 {

	public static void main(String[] args) {
		System.out.println("U   U" + "\t" + "B B" + "\t" + "  C C");
		System.out.println("U   U" + "\t" + "B   B" + "\t" + "C");
		System.out.println("U   U" + "\t" + "B B" + "\t" + "C");
		System.out.println("U   U" + "\t" + "B   B" + "\t" + "C");
		System.out.println("U   U" + "\t" + "B B" + "\t" + "  C C");
	}

}
