
public class Q3 {

	public static void main(String[] args) {
		double d, g, t;
		
		g= 9.81;
		t = 12;
		
		d = (g*t*t)/2;
		
		System.out.println("Distance after" + t + "seconds:" + d);

	}

}
