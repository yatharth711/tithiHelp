
public class Q2 {

	public static void main(String[] args) {
		double area;
		double perimeter;
		double height, width;
		
		height = 9;
		width = 7;
		
		area = height * width;
		perimeter = 2 * (height + width);
		
		System.out.println("Area:" + area + "\n" + "Perimeter:" + perimeter);
		

	}

}
