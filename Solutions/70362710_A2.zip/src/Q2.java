import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the driving distance in miles: ");
		double miles = in.nextDouble();
		
		in.nextLine();
		
		System.out.print("Enter miles per gallon: ");
		double gallon = in.nextDouble();
		
		in.nextLine();
		
		System.out.print("Enter price in $ per gallon: ");
		double price = in.nextDouble();
		
		in.nextLine();
		
		double cost = (miles * price)/gallon;
		
		System.out.print("The cost of driving is $" + cost );

	}

}
