import java.util.Scanner;

public class Q1 {

	
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			System.out.print("Enter time in seconds: ");
			int time = input.nextInt();
			convertTime(time);
		}
		public static void convertTime(int totalSeconds) {
			int s = totalSeconds % 60;
			int m = (totalSeconds / 60) % 60;
			int h = (totalSeconds / 60) / 60;
	    System.out.printf("%d:%d:%d", h, m, s);
	}

	

}
