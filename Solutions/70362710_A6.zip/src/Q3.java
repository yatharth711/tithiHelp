
import java.util.Scanner;
public class Q3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		int number = input.nextInt();
		
		System.out.println(number + (isPalindrome(number) ? " is " : " is not ") + "a palindrome.");

	
	}public static int reverse(int number) {
		String rev = "";
		String x = number +"";
		
		for(int i = x.length()-1;i>=0;i--) {
			rev += x.charAt(i);
		}
		return Integer.parseInt(rev);
	}
	
	public static boolean isPalindrome(int number) {
		return number == reverse(number) ? true : false;
			
		}
	}

