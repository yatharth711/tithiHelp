

import java.util.Scanner;

public class Q2 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); 

		
		System.out.print("Enter three sides for a triangle: ");
		double side1 = input.nextDouble();
		double side2 = input.nextDouble();
		double side3 = input.nextDouble();
		double sum12 = side1 + side2;
		double sum23 = side2 + side3;
		double sum13 = side1 + side3;
		
		while(isValid(side1,side2,side3)) {
			
			System.out.print("Invalid Input. Try again" + "\n" +"Enter three sides for a triangle: ");
			side1 = input.nextDouble();
			side2 = input.nextDouble();
			side3 = input.nextDouble();
			}if(isValid(side1,side2,side3)== false)				
				System.out.printf("Area: %.3f",area(side1,side2,side3));
			 
			
		
		
	}

	
	public static boolean isValid(double side1, double side2,double side3) {
		double sum12 = side1 + side2;
		double sum23 = side2 + side3;
		double sum13 = side1 + side3;
		boolean valid =
				side1 < 0 || side2 < 0 || side3 < 0 || sum12 < side3 || sum23< side1 || sum13 < side2;
				
		return valid;
	}

	
	public static double area(double side1, double side2, double side3) {
		double s = (side1 + side2 + side3) / 2;
		return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
	}
	
}