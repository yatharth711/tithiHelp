
public class Q2 {

	public static void main(String[] args) {
		BankAccount b = new BankAccount(6.7,33000);
		b.withdraw(1500);
		b.deposit(1000);
		b.displayInfo();

	}
	static class BankAccount{
		private int id=1;
		private double balance;
		private double annualInterestRate;
		private static int count = 1;
		
		public BankAccount() {
			this.annualInterestRate=0;
			this.balance=0;
			}
		
		public BankAccount(double annualInterestRate,double balance){
			this.annualInterestRate=annualInterestRate;
			this.balance=balance;
			count++;
			count=id;
		}
		public double getMonthlyInterest() {return (balance * annualInterestRate / 12)/100;}
		public void setId(int id) {this.id = id;}
	    public void setBalance(double balance) {this.balance = balance;}
	    public void setAnnualInterestRate(double annualInterestRate) {this.annualInterestRate = annualInterestRate;}
	    public void withdraw(double amount) {this.balance -= amount;}
	    public void deposit(double amount) {this.balance += amount;}
	    public void displayInfo(){
	    	System.out.println("Acount ID: "+ id);
	    	System.out.println("Current Balance:$ "+ balance);
	    	System.out.println("Annual Intrest Rate: " +annualInterestRate+"%");
	    	System.out.println("Monthly Intrest Rate: "+ getMonthlyInterest()/balance *100+"%");
	    	System.out.println("Monthly Intrest:$ " +getMonthlyInterest());
	    }
	}
}
