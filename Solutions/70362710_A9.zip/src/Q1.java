	public class Q1{
		public static void main(String[] args) {
			Cuboid c1 = new Cuboid();
			Cuboid c2 = new Cuboid(8,3.5,5.9,"Green");
			System.out.println("Cuboid 1");
			c1.displayInfo();
			System.out.println("Cuboid 2");
			c2.displayInfo();
		}


	}
	class Cuboid {
		private double l,w,h;
		private String color;
		
		public Cuboid()
		{this.l=1;
		this.w=1;
		this.h=1;
		this.color="White";}
		
		public Cuboid(double l, double w, double h, String color) {
			this.l=l;
			this.w=w;
			this.h=h;
			this.color=color;
		}
		
		public double getSurfaceArea() {return 2*(l*w+l*h+w*h);}
		public double getVolume() {return l*w*h;}
		public void displayInfo() {
			System.out.println("Color: "+color);
			System.out.println("Dimensions: "+l+" X "+w+" X "+h);
			System.out.println("Surface Area: "+getSurfaceArea());
			System.out.println("Volume: "+ getVolume()+"\n");
		}
	}
	