import java.util.Random;

public class Q5 {
	public static void main(String[] args) {
		Random output = new Random();
		
		char a = (char)('A' + output.nextInt(26));
		char b = (char)('A' + output.nextInt(26));
		char c = (char)('A' + output.nextInt(26));
		
		int w = (int)(Math.random() * 10);
		int x = (int)(Math.random() * 10);
		int y = (int)(Math.random() * 10);
		int z = (int)(Math.random() * 10);
		
		System.out.printf("A random vehicle number plate: %c%c%c%d%d%d%d",a,b,c,w,x,y,z);
		
	}

}
