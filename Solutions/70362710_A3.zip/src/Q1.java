 import java.util.Scanner;

 public class Q1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);		
		System.out.print("Enter the temperature in Farenheit between -58 F and 41 F: ");
		double temp = input.nextDouble();
		
		System.out.print("Enter the wind speed miles per hour (must be greater than or equal to 2) : " );
		double v = input.nextDouble();
		
		double t =  35.74 + 0.6215 * temp - 35.75 * Math.pow(v ,0.16) + 0.4275 * temp * Math.pow(v, 0.16);
		
		System.out.printf("The windchill index is %f",t);
		

	}

}
