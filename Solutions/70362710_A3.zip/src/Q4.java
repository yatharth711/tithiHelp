
import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Welcome to the multiple values calculator\n");
		System.out.print("Enter first number:  ");
		double x = input.nextDouble();
		System.out.print("Enter second number:  ");
		double y = input.nextDouble();
		
		double op1 = x + y ; // adds the numbers		
		double op2 = x - y;  // subtracts the numbers
		double op5 = ++x; // increments number 1		
		double op7 = --y; // The first number decremented 
		double op3 = x*=10;  // multiplies first number + +1 by 10
		 
		
		
		
		System.out.printf("The sum is %f\n",op1 );
		System.out.printf("The difference is %f\n",op2 );
		System.out.printf("The number +1 multiplied by 10 is %f\n",op3 );		
		System.out.printf("The first number incremented %f\n",op5 );		
		System.out.printf("The first number decremented after multiplied to ten %f\n",op7 );
		
		
	}

}
