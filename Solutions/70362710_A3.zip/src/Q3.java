
import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an integer between 0 and 1000: ");
		int x = input.nextInt();
		
		int num1 = x % 10;
		int rem = x / 10;
		int num2 = rem % 10;
		rem = rem /10;
		int num3 = rem % 10;
		rem = rem / 10;
		int num4 = rem % 10;
		int sum = num1 + num2 + num3+ num4;		
		
		System.out.printf(" The sum of all digits in %d is %d ", x, sum);

	}

}
