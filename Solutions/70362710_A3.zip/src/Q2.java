
import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a real number: ");
		double x = input.nextDouble(); 
        int y = (int)Math.floor(x); 
        double c = x - y; 
 
        System.out.printf("Integral part = %f \n",x); 
        System.out.printf("Fractional part = %f",c);

	}

}
