package StudentMarks;

import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("How many numbers in the list?");
		int n = input.nextInt();
		System.out.print("Enter the list: ");
		
		double[] array = new double[(int) n];		
		for(int i=0;i<n;i++) {
			array[i]=input.nextDouble();			
		}
		boolean result = isSorted(array);
		if(result==true) {
			System.out.print("The list is already sorted");
		}else {
			System.out.print("The list is not sorted");
		}
		
	}
	public static boolean isSorted(double[] array) {
	    double temp = array[0];
	    
	    for (int i = 1; i < array.length; i++) {
	        double numbers = array[i];
	        if (temp >= numbers) {
	            return false;
	        }
	        temp = numbers;
	    }
	    
	    return true;
	
	}
}












