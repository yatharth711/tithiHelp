package StudentMarks;
import java.lang.reflect.Array;
import java.util.Arrays;

import StudentMarks.Q1;
public class Q2 {

	public static void main(String[] args) {
		Q1 marks = new Q1();
		String s1 = "Enter number of students: ";
		String s2 = "Enter students grades: ";
		double[] grades = marks.getNumsFromUser(s1, s2);
		
		double max = grades[0];
		for(int i = 1;i<grades.length;i++) {
			if(grades[i]>max) {
				max = grades[i];
			}
		}
		for(int i =0;i<grades.length;i++) {
			double cal = grades[i];
			if(cal >= max - 10 ) {
				System.out.print("Student "+i+" score is "+grades[i]+" grade is A \n");
			}
			else if(cal>=max-20) {
				System.out.print("Student "+i+" score is "+grades[i]+" grade is B\n");
			}
			else if(cal>=max-30) {
				System.out.print("Student "+i+" score is "+grades[i]+" grade is C \n");
			}
			else if(cal>=max-40) {
				System.out.print("Student "+i+" score is "+grades[i]+" grade is D \n");
			}else{
				System.out.print("Student "+i+" score is "+grades[i]+" grade is F \n");
			}
		}
		
		}
	//public static void showLetterGrades(double[] grades) {
		
	//}
	

}
	