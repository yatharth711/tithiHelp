package StudentMarks;
import java.util.Arrays;
import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		String s1 = "Enter number of students: ";
		String s2 = "Enter students grades: ";
		double[] numbers = getNumsFromUser(s1,s2);
		System.out.println(Arrays.toString(numbers));
	}
	public static double[] getNumsFromUser(String msg1,String msg2) {
		Scanner input = new Scanner(System.in);
		System.out.print(msg1);
		double n= input.nextDouble();
		
		double[] array = new double[(int) n];
		System.out.print(msg2);
		for(int i=0;i<n;i++) {
			array[i]=input.nextDouble();
			
		}
		return array;
	}
}
